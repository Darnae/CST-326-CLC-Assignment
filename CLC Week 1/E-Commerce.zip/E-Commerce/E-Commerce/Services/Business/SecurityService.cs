﻿using E_Commerce.Models;
using E_Commerce.Services.DataAccess;

namespace E_Commerce.Services.Business
{
    /// <summary>
    /// Service for managing user security operations.
    /// </summary>
    public class SecurityService
    {
        // Create an object of the DAO class so we can use
        // the database lookup query
        SecurityDAO securityDAO = new SecurityDAO();

        /// <summary>
        /// Validates the user credentials.
        /// </summary>
        /// <param name="user">The user model containing the credentials.</param>
        /// <returns>True if the user credentials are valid, otherwise false.</returns>
        public bool IsValid(UserModel user)
        {
            return securityDAO.FindUserByNameAndPassword(user);
        }

        /// <summary>
        /// Registers a new user.
        /// </summary>
        /// <param name="user">The registration model containing user data.</param>
        /// <returns>True if the registration is successful, otherwise false.</returns>
        public bool Register(RegistrationModel user)
        {
            return !securityDAO.UserExists(user.Username, user.Email) && securityDAO.RegisterUser(user);
        }
        public bool UserExists(string username, string email)
        {
            return securityDAO.UserExists(username, email);
        }
    }
}
