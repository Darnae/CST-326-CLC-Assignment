using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Drawing;
using System;
using E_Commerce.Models;
using Microsoft.Data.SqlClient;
namespace E_Commerce.Services.DataAccess
{
    public class SecurityDAO
    {
        // Testing database connection string
        private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Test;Integrated Security=True;Connect Timeout=30;Encrypt=False;";

        //this method is going to create a sql query in the method to search for a record by username and password it returns true if match is found
        //returns boolean 
        public bool FindUserByNameAndPassword(UserModel user)
        {
            //assume nothing is found
            //declare and initialize our flag as false
            bool isSuccessful = false;

            //query string to query db for password and username
            string sqlStatement = "SELECT * FROM [RegistrationMain] WHERE UserName = @userName AND PasswordHash = @passWord";
            //using statement to ensure objects are disposed of correctly
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                //instantiate the sql command pass the constructor query string and connection
                //sql command to allow us to query and send commands to the database 
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                //Define the value of the two placeholders in the query
                //using the object "command"
                command.Parameters.Add("@userName",
                    System.Data.SqlDbType.VarChar, 40).Value = user.UserName;
                command.Parameters.Add("@password",
                    System.Data.SqlDbType.VarChar, 40).Value = user.PasswordHash;

                //going to use try catch when opening a db just in case there is an exception
                try
                {
                    //use the connection object
                    connection.Open();
                    //execute the query and read the results
                    //command object has already had the query statement sent
                    //to the constructor
                    SqlDataReader reader = command.ExecuteReader();

                    // lets see if there are any rows found
                    if (reader.HasRows)
                    {
                        //update the flag so we can return that our user was found
                        isSuccessful = true;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            //Return the results
            return isSuccessful;
        }
        public bool UserExists(string username, string email)
        {
            bool exists = false;

            string sqlStatement = "SELECT COUNT(*) FROM [RegistrationMain] WHERE Username = @Username OR Email = @Email";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Email", email);

                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        exists = true; // User already exists
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return exists;
        }

        public bool RegisterUser(RegistrationModel user)
        {
            if (UserExists(user.Username, user.Email))
            {
                return false; // Username or email already exists
            }

            bool isSuccess = false;
            string sqlStatement = @"
        INSERT INTO [RegistrationMain] (FirstName, LastName, Sex, Age, State, Email, Username, PasswordHash)
        VALUES (@FirstName, @LastName, @Sex, @Age, @State, @Email, @Username, @PasswordHash)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@FirstName", user.FirstName);
                command.Parameters.AddWithValue("@LastName", user.LastName);
                command.Parameters.AddWithValue("@Sex", user.Sex ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Age", user.Age.HasValue ? user.Age : DBNull.Value);
                command.Parameters.AddWithValue("@State", user.State ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Email", user.Email);
                command.Parameters.AddWithValue("@Username", user.Username);
                command.Parameters.AddWithValue("@PasswordHash", user.Password);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    isSuccess = rowsAffected == 1;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return isSuccess;
        }
    }
}

