﻿using E_Commerce.Models;
using E_Commerce.Services.Business;
using Microsoft.AspNetCore.Mvc;

namespace E_Commerce.Controllers
{
    /// <summary>
    /// Controller for user registration.
    /// </summary>
    public class RegistrationController : Controller
    {
        private SecurityService securityService;

        /// <summary>
        /// Constructor for RegistrationController.
        /// </summary>
        public RegistrationController()
        {
            // Initialize the SecurityService.
            securityService = new SecurityService();
        }

        /// <summary>
        /// Action method for rendering the registration form.
        /// </summary>
        /// <returns>The registration view.</returns>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Action method for handling user registration, will check database if user is already registered
        /// </summary>
        /// <param name="model">The registration model containing user data.</param>
        /// <returns>The result of the registration attempt.</returns>
        [HttpPost]
        public IActionResult ShowRegistrationDetails(RegistrationModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if username or email already exists
                if (securityService.UserExists(model.Username, model.Email))
                {
                    ModelState.AddModelError("", "Username or email already exists. Please try a different one.");
                    return View("Index", model); // Redirect back to the registration form
                }

                // Proceed with registration if no duplicate is found
                if (securityService.Register(model))
                {
                    TempData["SuccessMessage"] = "Registration successful!";
                    return View("ShowRegistrationDetails", model);
                }
                else
                {
                    ModelState.AddModelError("", "An error occurred while registering. Please try again.");
                }
            }

            return View("Index", model); // Redirect back to the registration form on failure
        }

    }
}
