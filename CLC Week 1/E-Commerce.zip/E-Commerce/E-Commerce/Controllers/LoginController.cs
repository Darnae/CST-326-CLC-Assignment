﻿using E_Commerce.Models;
using E_Commerce.Services.Business;
using Microsoft.AspNetCore.Mvc;

namespace E_Commerce.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Processes the login and redirects based on authentication result.
        /// </summary>
        [HttpPost]
        public IActionResult ProcessLogin(UserModel user)
        {
            SecurityService securityService = new SecurityService();

            if (securityService.IsValid(user))
            {
                // Redirect to the LoginSuccess view
                return RedirectToAction("LoginSuccess", "Login");
            }
            else
            {
                // Redirect to the LoginFailure view with the user model
                return View("LoginFailure", user);
            }
        }

        public IActionResult LoginSuccess()
        {
            // You can customize this action method as needed
            return View();
        }
    }
}