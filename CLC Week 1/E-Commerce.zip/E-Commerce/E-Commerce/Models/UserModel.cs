namespace E_Commerce.Models
{
    public class UserModel
    {
        //Declare class properties
        public int Id { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string? PasswordHash { get; set; } 
        //using ? to declare non nullible
    }
}
